const swalst = Swal.mixin({
    timer: 2500,
    allowOutsideClick: false,
    showConfirmButton: false,
    timerProgressBar: true,
    imageHeight: 100,
    imageWidth: 100,
});

async function pesanAwal() {
    await swalst.fire({
        title: 'Chào cục cưngg! ❤️',
        imageUrl: 'cat1.png',
    });

    await swalst.fire({
        title: 'Tớ chỉ muốn nói 😍',
        imageUrl: 'cat2.png',
    });

    await swalst.fire({
        title: 'Tuyệt sắc giai nhân phải yêu taa 🤭❤️',
        imageUrl: 'rabbit.png',
    });

    await swalst.fire({
        title: 'Valentine để ta ôm 🥺❤️',
        imageUrl: 'cat-rabbit.png',
    });

    await swalst.fire({
        title: 'Valentine làm vợ yêu tuii nhaa 😘💕',
        imageUrl: 'cat-love-rabbit.png',
    });

    mulaikonten();
}

function memulai() {
    document.getElementById("background-music").play();
    pesanAwal();
}

function mulaikonten() {
    setInterval(berjatuhan, 800);
}

function berjatuhan() {
    const heart = document.createElement("div");
    heart.innerHTML = "<img src='heart.png' class='heart-icon' />";
    heart.style.left = (Math.random() * 95) + "vw";
    heart.style.animationDuration = (Math.random() * 3) + 2 + "s";
    document.body.appendChild(heart);
}

setInterval(function () {
    var heartArr = document.querySelectorAll(".heart-icon");
    if (heartArr.length > 100) {
        heartArr[0].remove();
    }
}, 100);

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById("background-music").play();
});
